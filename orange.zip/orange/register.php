
<h1>Register</h1>
<form>
	Username:<input type="text" name="username"><br><br><br>
	Password:<input type="password" name="password"><br><br><br>
	Retype-Password<input type="text" name="retype"><br><br><br>
	<input type="submit" value="Register">
</form>