<form action="process.php" method="post">
	Email:<input type="text" name="email">
	Password:<input type="text" name="password">
	<input type="submit" value="Save">
</form>


<a href="process.php?email=salameh@gmail.com&password=123456&id=4&dept=IT">Go To Process</a>